<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน เครื่องฉายเลเซอร์ ไม้,โลหะ,ยางรถยนต์,ไม้กอล์ฟ,ผ้า,งานเชื่อมโลหะ,เมนบอร์ด</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
<script src="../js/change_img.js" type="text/javascript"></script>
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="29%" valign="top"><?include("../include/list_product_th.php")?></td>
    <td valign="top" style="padding:0px 0px 0px 12px;">
	<div class="head2 style1">Laser Projector Cross-Line Marking </div>

<p align="center"><table width="650" border="0">
  <tr>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_9000c"><img src="../images/product/kml_9000c.jpg" alt="" height="150"/></a></div></td>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_3000c"><img src="../images/product/kml_3000_2.jpg" alt="" height="150" /></a></div></td>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_3000"><img src="../images/product/kml_2000c.jpg" alt="" height="150" /></a></div></td>
  </tr>
  <tr>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_9000c">KML-9000</a></div></td>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_3000c">KML-3000C</a></div></td>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_3000">KML-2000</a></div></td>
  </tr>
  <tr>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_2000"><img src="../images/product/kml_1000c.jpg" alt="" height="150" /></a></div></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="../th/p_Laser-Projector.php?p=kml_2000">KML-1000</a></div></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
  </tr>
</table></p>

</td>
    </tr>
</table>




	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
