<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน แกะสลักงานได้ต่อเนื่องแม้ไฟดับ</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
<script src="../js/change_img.js" type="text/javascript"></script>
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="29%" valign="top"><?include("../include/list_product_th.php")?></td>
    <td valign="top" style="padding:0px 0px 0px 12px;">
	<div class="head2">รายละเอียดของสินค้า<h3>SIGNKEY CNC Engraver Series : | <a href="?p=sk-1">SK-1212F 1500w, SK-1318F 2200W, SK-1325F 2200W, SK-1325FS 2200W</a> | <a href="?p=sk-3">SK-3226B, SK-3226C</a></h3>
	</div>
	
<!--CNC Engraver-->
<p><h2>SIGNKEY CNC Engraver Series</h2>
<? if($_GET["p"]=="sk-1" || $_GET["p"]=="") { ?>
<img src="../images/product/SK-121_131_132.jpg" class="img2" />
<h3>SK-1212F 1500w : 1200*1200*90มม</h3>
<h3>SK-1318F 2200W : 1300*1800*90มม</h3>
<h3>SK-1325F 2200W : 1300*2500*90มม</h3>
<h3>SK-1325FS 2200W : 1300*2500*90มม LINER GUIDE GEAR RULLER</h3>
<h2 style="margin-top:90px;">คุณลักษณะ และการใช้งาน</h2>
<h5 class="col_R">คุณลักษณะทั่วไป</h5>
<h5>1. ระบบควบคุมการทำงาน</h5>
ควบคุมการทำงานด้วยระบบตัวเลขแบบ DSP และมีจอ LCD ซึ่งง่ายต่อการใช้ง่าย<br />
มีโปรแกรมคำนวณการทำงานเพื่อให้งานออกมามีประสิทธภาพ และสามารถเพิ่มความเร็วในการทำงานที่มีเส้นตรง และโค้งได้สวยงาน และต่อเนื่อง

<h5>2. มีหน่วยความจำขนาดใหญ่และการถ่ายข้อมูลดี</h5>
มีหน่วยความจำขนาด 32 MB และสามารถเก็บไฟล์งานได้มากกว่า 30 ไฟล์<br />
สามารถใช้ USB ร่วมกันกับระบบ Window98/NT/2000/XP ในการส่งรับข้อมูล

<h5>3. ประสิทธิภาพสูง </h5>
เพื่อให้มีประสิทธิภาพสูงควรใช้ร่วมกับโปรแกรม CAD / CAM / Type3 / Artcam / Castmate / Proe / UG และ Artcut

<h5>4. ออกแบบได้</h5>
สามารถแกะสลักงานได้ต่อเนื่องแม้ไฟดับ หรืออุปกรณ์บางชิ้นเสียหาย
มีระบบแกนควบคุมสามารถเริ่ม และหยุดการทำงานได้อัตโนมัติ ซึ่งปลอดภัย,สะดวก และช่วยประหยัดพลังงาน

<h5>5. หัวเจาะแบบเพชร</h5>
สามารถตัดกระจกที่มีความหนา 20-30 มม. ได้ในการตัดครั้งเดียว

<h5 class="col_R">การใช้งาน</h5>
เหมาะสำหรับการทำโลโก้, งานแบบ 3 มิติ, งานไม้ และการออกแบบจำลอง

<h5 class="col_R">อุปกรณ์เสริม</h5>
หน่วยความจำ 128 MB, แฟลชไดรฟ์, แกนของรุ่น 2200W, อุปกรณ์เก็บฝุ่น, แกนพ่วง



<? } if($_GET["p"]=="sk-3") { ?>
<table>
  <tr align="center"><td style="padding-right:15px;"><img src="../images/product/SK-3226B.jpg" alt="SK-3226B" class="boder_img" /><br /><h3>SK-3226B : 300*250*80มม</h3></td>
  <td><img src="../images/product/SK-3226C.jpg" alt="SK-3226C" class="boder_img" /><br /><h3>SK-3226C : 300*250*80มม</h3></td></tr>
</table>
<h2>คุณลักษณะ และการใช้งาน</h2>
<h5 class="col_R">คุณลักษณะทั่วไป</h5>
ถูกลิขสิทธิ์<br />
แข็งแรงทนทาน<br />
โครงสร้างแข็งแกร่ง, มีแกนที่แข็งแรงเพื่อทำชิ้นงานได้อย่างเที่ยงตรง แม่นยำ และมีความสั่นสะเทือนน้อย<br />
มีแกน X, Y, Z ที่มีประสิทธิภาพสูงทำให้การงานมีความแม่นยำ<br />
สามารถใช้คอมพิวเตอร์แบบ Dual Cores หรือ DDA เพื่อคำนวณการทำงานเส้นโค้ง และเส้นตรงให้ได้งานที่มีคุณภาพ<br />
การเดินเครื่องทรงพลัง แม่นยำ แต่เสียงดังน้อย<br />
ใช้โปรแกรม CAD/CAM ร่วมกันทำงาน<br />
สามารถส่งไฟล์ผ่าน RS-232 และ U Disk
<h5 class="col_R">อุปกรณ์เสริม</h5>
สามารถเลือกความสูงของแกน และชนิดของใบมีดได้
<h5 class="col_R">การใช้งาน</h5>
เหมาะสำหรับงานออกแบบ, งานโฆษณา, งานตรายาง, ทำโลโก้ลงบนสินค้าชนิดต่าง ๆ เช่น เครื่องดนตร, ใบมีด, แผ่นเหล็ก, ตรายาง, แผ่นคาร์บอนของแบตเตอรี, แผ่นทองแดง และชิ้นงานขนาดเล็กได้

<? } ?>
<!--end CNC Engraver-->

</td>
    </tr>
</table>




	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
