<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="950" height="340">
      <param name="movie" value="../images/head.swf" />
      <param name="quality" value="high" />
      <embed src="../images/head.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="950" height="340"></embed>
    </object></td>
  </tr>
  <tr>
    <td>
<?include("../include/Model.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:10px 0px;">
<? /*<!--ข่าวสารล่าสุด-->
<div class="blog"><p class="head1"><span class="col_R15">ข่าวสาร</span>ล่าสุด</p>
  <a href="news.php"><img src="../images/discover_news.jpg" width="214" border="0" /></a></div>
</div>*/
?>

<div class="blog"><p class="head1"><span class="col_R15">สินค้า</span>สุดพิเศษ</p>
<a href="p_Laser-Cutting.php?p=hl" class="box"><img src="../images/HL01.gif" border="0" class="img1" /><strong>Laser Cutting Machine : HL-1390</strong><br />
คุณสมบัติ : 
พื้นที่การทำงาน 1300 x 900 มม.
ความเร็วในการสลัก 0-64000 มม./นาที
การควบคุมแสงเลเซอร์ ควบคุมโดยระบบ อัตโนมัติด้วยการกำหนดสีในการตัด </a></div>

<div class="blog"><p class="head1"><span class="col_R15">News</span></p>
  <a href="news.php" class="box"><img src="../images/image001.jpg" width="195" height="84" border="0" class="img1" /></a>
  <h4><br />
    Date: 19-22/MAY/2011<br />
    Booth: C8</h4>
</div>

 <div class="blog"><a href="service-support.php" class="box"><p class="head1"><span class="col_R15">บริการชิ้นงาน</span>และซ่อมบำรุง</p>
 </a>
 ทางบริษัทฯ มีทีมช่างคุณภาพ ไว้คอยบริการดูแลรักษาเครื่อง แนะนำ และจัดหาอะไหล่ให้ลูกค้าที่ครบวงจร<br />
 <a href="service-support.php"><img src="../images/serviceandsupport.jpg" border="0" /></a> </div>
 
<div class="blog" style="margin-right:0px; background:url(../images/mapss.jpg) top right no-repeat #EFF0F1;"><p class="head1"><span class="col_R15">ติดต่อ</span>เรา</p>
<a href="contactus.php" class="box">
    255 <br />
ซอยอ่อนนุช 44 <br />แขวงสวนหลวง, <br />เขตสวนหลวง <br />กรุงเทพฯ <br />10250</a></div></td>
  </tr>
  <tr>
    <td><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
