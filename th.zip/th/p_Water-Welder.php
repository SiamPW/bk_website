<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน เครื่องเป่าไฟ การขัดเงาด้วยไฟ ผลิตภัณฑ์ที่ได้ขอบจะเงาสวยงาม</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
<script src="../js/change_img.js" type="text/javascript"></script>
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="29%" valign="top"><?include("../include/list_product_th.php")?></td>
    <td valign="top" style="padding:0px 0px 0px 12px;">
	<div class="head2">รายละเอียดของสินค้า
	</div>

<h2>เครื่องเป่าไฟ</h2>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr align="center">
    <td><img src="../images/product/water_welder_01.jpg" class="boder_img" /><br />
      <strong>Water Welder</strong></td>
    <td><img src="../images/product/water_welder_02.jpg" class="boder_img" /><br />
      <strong>Diffusion pipe 2 heads</strong></td>
  </tr>
</table>

<h5 class="col_R">คุณลักษณะของเครื่องโดยทั่วไป</h5>
<table border="0" cellspacing="1" cellpadding="4" width="100%" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>FP 101</td>
    <td>FP 202</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาด</td>
    <td>44x23x28 ซม.</td>
    <td>44x23x28 ซม.</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td>29 กก.</td>
    <td>33 กก.</td>
  </tr>
  <tr align="center">
    <td align="left">ระบบไฟ</td>
    <td>220V 50-60 Hz</td>
    <td>220V 50-60 Hz</td>
  </tr>
  <tr align="center">
    <td align="left">กระแสไฟ </td>
    <td>800 w</td>
    <td>1000 w</td>
  </tr>
  <tr align="center">
    <td align="left">อัตราการสิ้นเปลืองของน้ำ</td>
    <td>40 cc./ชม</td>
    <td>50 cc./ชม</td>
  </tr>
  <tr align="center">
    <td align="left">อัตราการสิ้นเปลืองของแก็ส </td>
    <td>200 ลิตร/ชม</td>
    <td>250 ลิตร/ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ที่เป่าไฟ </td>
    <td>2</td>
    <td>2</td>
  </tr>
</table>


<h5 class="col_R">วิธีการใช้งาน และตัวอย่าง</h5>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td style="padding-right:20px;"><img src="../images/product/water_welder_03.jpg" class="boder_img" /></td>
    <td>การขัดเงาด้วยไฟ โรงงานที่ไต้หวันจะใช้วิธีการซ้อนกัน และใช้ 
Water Welder
</td>
  </tr>
  <tr>
    <td><img src="../images/product/water_welder_04.jpg" class="boder_img" /></td>
    <td>ผลิตภัณฑ์ที่ได้ขอบจะเงาสวยงาม เพราะ Water Welder จะให้เปลวไปสีน้ำเงิน (การเผาไหม้ที่สมบูรณ์จะไม่เกิดเขม่า)</td>
  </tr>
</table>


</td>
    </tr>
</table>




	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
