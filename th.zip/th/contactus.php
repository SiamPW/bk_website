<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><?include("../include/Model.php")?></td>
  </tr>
  <tr>
    <td style="padding-top:5px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top">
	<div class="col1">
<a href="#" class="h-red">ติดต่อเรา</a>
<h3 class="head1" style="margin-top:10px;">บริษัท สยาม พี แอนด์ ดับบลิว เทคนิค จำกัด</h3>

<p><strong>Address :</strong> 	255 ซอยอ่อนนุช 44 แขวงสวนหลวง, เขตสวนหลวง กรุงเทพฯ 10250</p>

<p><strong>Tel. :</strong> 	66(2)730-6645-7<br />
<strong>Fax. :</strong> 	66(2)730-6648<br />
<strong>E-mail :</strong>  <a href="mailto:sales@siampw.com">sales@siampw.com</a>, <a href="mailto:laserpw@yahoo.com">laserpw@yahoo.com</a></p>
<strong>Website :</strong> www.siampw.com</div>	


</td>
    <td valign="top" style="width:630px; padding:0px 0px 0px 12px;">
	<div class="head2">แผนที่ : บริษัท</div>
	<img src="../images/maps.jpg" />
<!--iframe style="border:solid 1px #D3D6D9;" width="628" height="290" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps/ms?ie=UTF8&amp;hl=en&amp;msa=0&amp;msid=108748948181068891786.000468be2e4cc7eddc9dd&amp;ll=13.708993,100.630238&amp;spn=0.006045,0.013475&amp;z=16&amp;output=embed"></iframe><br /><small>View <a href="http://maps.google.com/maps/ms?ie=UTF8&amp;hl=en&amp;msa=0&amp;msid=108748948181068891786.000468be2e4cc7eddc9dd&amp;ll=13.708993,100.630238&amp;spn=0.006045,0.013475&amp;z=16&amp;source=embed" target="_blank" style="color:#0000FF;text-align:left">SIAM P&W TECHNIC CO., LTD.</a> in a larger map</small--></td>
  </tr>
</table>	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
