<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
<script src="../js/change_img.js" type="text/javascript"></script>
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="29%" valign="top"><?include("../include/list_product_th.php")?></td>
    <td valign="top" style="padding:0px 0px 0px 12px;">
	<div class="head2">รายละเอียดของสินค้า
	</div>
	
<h2>Liner Marking : LMF</h2>

<img alt="Liner Marking : LMF" src="../images/product/lmf_01.jpg" class="img2" />
<table width="50%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
<h5 class="col_R">คุณสมบัติเด่น</h5>
<ul type="circle">
<li>แสงเลเซอร์มีกำลังแรงสูง</li><li>ออกแบบมาเพื่อรองรับระบบ OEM
</li><li>พื้นที่ในการยิงเลเซอร์กว้าง
</li><li>ชิ้นงานที่ยิงเลเซอร์ได้อยู่คงทน 
</li><li>สามารถยิงเลเซอร์ลงบนชิ้นงานได้ลึกถึง 2 มม.
</li><li>ง่ายต่อการบำรุงรักษา
</li><li>ยิงเลเซอร์ได้เร็ว และมีความแม่นยำสูง
</li><li>สามารถยิงเลเซอร์เส้นเล็กได้ (0.1 mm)
</li>
</ul>
<img src="../images/product/lmf_02.jpg" /></td>
  </tr>
</table>

<div style="clear:both;">&nbsp;</div>
<h5 class="col_R">คุณลักษณะของเครื่องเลเซอร์โดยทั่วไป</h5>
<table border="0" cellspacing="1" cellpadding="4" width="100%" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>5W/ 10W/ 20W</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวแสง</td>
    <td>1062 มม. </td>
  </tr>
  <tr align="center">
    <td align="left">พื้นที่การยิงเลเซอร์</td>
    <td>70 x 70 มม. /100 x    100 มม.</td>
  </tr>
  <tr align="center">
    <td align="left">ยิงเลเซอร์ลึกสุด</td>
    <td>*2 มม. </td>
  </tr>
  <tr align="center">
    <td align="left">ยิงเลเซอร์เส้นเล็กสุด</td>
    <td>]0.1 มม. (ขึ้นอยู่กับวัสดุ) </td>
  </tr>
  <tr align="center">
    <td align="left">ยิงเลเซอร์ตัวหนังสือเล็กสุด</td>
    <td>]0.4 มม. (ขึ้นอยู่กับวัสดุ) </td>
  </tr>
  <tr align="center">
    <td align="left">ความละเอียดการยิงเลเซอร์ซ้ำ</td>
    <td>&nbsp;
        *6 0.01 มม.</td>
  </tr>
  <tr align="center">
    <td align="left">ความเร็วในการยิงสูงสุด</td>
    <td>700 มม./วินาที </td>
  </tr>
  <tr align="center">
    <td align="left">ระบบไฟ</td>
    <td>110V/220V , 1 f , 5A,    50/60 Hz</td>
  </tr>
  <tr align="center">
    <td align="left">ระบบหล่อเย็น</td>
    <td>ระบบอากาศ </td>
  </tr>
  <tr align="center">
    <td align="left">ขนาด </td>
    <td>450 x 130 x 110 มม.</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดระบบควบคุม </td>
    <td>426 x 400 x88 มม. </td>
  </tr>
  <tr align="center">
    <td align="left">โปรแกรม    CAM </td>
    <td>Marking Mate </td>
  </tr>
</table>

<h5 class="col_R">สามารถตัดชิ้นงานดังต่อไปนี้</h5>
อิเล็กทรอนิกส์ บอร์ด, PC คีย์บอร์ด, ผ้า, มีด, กระดุม, รันนัมเบอร์ และวันที่, เหล็ก และ PVC

<img src="../images/product/lmf_03.jpg" hspace="20" vspace="10" />
</td>
    </tr>
</table>




	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
