<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน เครื่องแกะสลักเลเซอร์สามารถตัด แกะสลัก และเจาะได้ </title>
<link href="../css.css" rel="stylesheet" type="text/css" />
<script src="../js/change_img.js" type="text/javascript"></script>
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="29%" valign="top"><?include("../include/list_product_th.php")?></td>
    <td valign="top" style="padding:0px 0px 0px 12px;">
	<div class="head2">รายละเอียดของสินค้า<h3>Laser Engraver Machine : | <a href="?p=lem">LEM</a> | <a href="?p=lee">LEE</a></h3>
	</div>

<? if($_GET["p"]=="lem" || $_GET["p"]=="") { ?>
<h2>Laser Engraver Machine : LEM</h2>
<img src="../images/product/lem.jpg" class="boder_img" />

<h5 class="col_R">คุณสมบัติเฉพาะ </h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
   <tr align="center">
     <td colspan="4"><strong>EZ-LASER LEM Series</strong></td>
     </tr>
   <tr>
    <td>เลเซอร์</td>
    <td>RF
      25 Watt Sealed CO2 Laser Tube<br />
      (Air-cooled)</td>
    <td>RF 60 Watt Sealed CO2 Laser Tube<br />
      (Air-cooled)</td>
    <td>RF 100 Watt Sealed CO2 Laser
      Tube<br />
      (Air-cooled)</td>
  </tr>
  <tr>
    <td >น้ำหนัก</td>
    <td>200 กก</td>
    <td>220 กก</td>
    <td>240 กก</td>
  </tr>
  <tr>
    <td >พื้นที่ทำงาน (กว้างxยาว)</td>
    <td  colspan="3">660.4
      x 304.8 มม (26&quot; x 12&quot;)</td>
  </tr>
  <tr>
    <td >ขนาด (กว้างxยาวxสูง)</td>
    <td  colspan="3">685.8
      x 330.2 มม. (27&quot;x 13&quot;)</td>
  </tr>
  <tr>
    <td >ขนาดทั้งหมด (กว้างxยาวxสูง)</td>
    <td  colspan="3">กว้าง
      960 x ยาว 765 x สูง 1,040 มม.</td>
  </tr>
  <tr>
    <td >สายคอมพิวเตอร์</td>
    <td  colspan="3">สายแบบ
      Pararel</td>
  </tr>
  <tr>
    <td >หน่วยความจำ</td>
    <td  colspan="3">64
      MB</td>
  </tr>
  <tr>
    <td >โฟกัสเลนส์</td>
    <td  colspan="3"> 2.0&quot;</td>
  </tr>
  <tr>
    <td >ความเร็วในการแกะสลัก</td>
    <td  colspan="3">40
      นิ้ว/วินาที</td>
  </tr>
  <tr>
    <td >ระบบควบคุมเลเซอร์</td>
    <td  colspan="3">ควบคุมเลเซอร์ให้ตัดชิ้น/ไม่ตัดชิ้นงานโดยใช้การควบคุมด้วยสี</td>
  </tr>
  <tr>
    <td >พลังงาน</td>
    <td  colspan="3">220VAC,
      6 Amp, 50/60Hz</td>
  </tr>
  <tr>
    <td >ซอฟต์แวร์</td>
    <td  colspan="3">EZ-LASER</td>
  </tr>
</table>


<h5 class="col_R">คุณสมบัติเด่น</h5>
<strong>คุณสมบัติเด่นของรุ่น EZ-LASER LEM</strong>
<ul type="circle">
<li>มีอุปกรณ์ช่วยทำให้ตัวเลเซอร์เคลื่อนที่ และตัดชิ้นงานได้เรียบสม่ำเสมอ
</li><li>ซอฟต์แวร์ EZ-LASER ทำงานบนระบบ Windows ในการใช้งานบน CorelDraw
</li><li>สามารถตัดชิ้นงานแกะเส้นกรอบด้านนอก และการแกะสลักชิ้นงานด้านในภายในเวลาเดียวกัน
  หรือแยกทำชิ้นงานได้
</li><li>มีการออกแบบให้ง่ายต่อการเปลี่ยนชิ้นส่วนประกอบเครื่อง ง่ายต่อการบำรุงรักษา และเคลื่อนย้าย
  เครื่องได้สะดวก
</li><li>สามารถเปลี่ยนระบบการทำงานได้โดยไม่ต้องส่งไฟล์งานจากคอมพิวเตอร์ เพื่อประหยัดเวลาใน
  การ ทำงาน
</li><li>มีระบบสูญญากาศเพื่อช่วยให้ชิ้นงานที่มีความบางและเบาให้ยึดติดกับเครื่องแกะสลัก
</li><li>เหมาะสำหรับงานหนัก และงานที่เกี่ยวกับตรายาง
</li><li>เหมาะสำหรับการแกะตรายางที่มีขนาดน้อยกว่าขนาด A4 หรือ ขนาด A4  ตามแนวขนาน หรือ
  ตามแนวดิ่งที่ขนาด A3 หรือ A4   
</li></ul>

<table width="70%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr align="center">
    <td><img src="../images/product/laserlife_lem-1.jpg" class="boder_img" /><br />มีระบบสูญญากาศเพื่อช่วยให้ชิ้นงาน
ที่มีความบางและเบาให้ยึดติดกับเครื่องแกะสลัก </td>
	<td width="50">&nbsp;</td>
	<td><img src="../images/product/laserlife_lem-2.jpg" class="boder_img" /><br />สามารถแกะสลักยางได้ลึกและดีกว่า
(25w/ 60w/ 100w) </td>
  </tr>
</table>


<h5 class="col_R">ความต้องการพื้นฐาน</h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
    <tr>
      <td>คอมพิวเตอร์</td>
      <td>Windows 98, ME, XP</td>
    </tr>
    <tr>
      <td>ระบบระบายควัน       </td>
      <td >เครื่องระบายกลิ่นและควัน 1 ตัว (3/4HP), ความกดอากาศที่
        70 mmAq,  ลมหมุน 16m3/นาที, สายฉีด 1 เส้น ขนาดผ่าศูนย์กลาง
        6” </td>
    </tr>
</table>

<h5 class="col_R">ชิ้นงานที่ได้จากเครื่อง LEM</h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
  <tr>
    <td colspan="2"><strong>ชิ้นงานที่ได้จากเครื่อง LEM</strong></td>
  </tr>
  <tr>
    <td> งานอะคริลิก</td>
    <td> งานปะเก็น</td>
  </tr>
  <tr>
    <td> งานตกแต่ง<br />
    </td>
    <td> ป้ายชื่อ</td>
  </tr>
  <tr>
    <td> สัญลักษณ์<br /></td>
    <td> งานฉลุผ้า</td>
  </tr>
  <tr>
    <td> วงแหวนลูกสูบ</td>
    <td> งานฉลุลาย</td>
  </tr>
  <tr>
    <td> งานที่มีพื้นผิวหยาบ</td>
    <td> งานผ้าพลาสติกใยสังเคราะห์</td>
  </tr>
  <tr>
    <td> งานโมเดลจำลอง</td>
    <td> ตรายาง</td>
  </tr>
  <tr>
    <td> งานโมเดลของเล่น</td>
    <td> กรอบรูป</td>
  </tr>
  <tr>
    <td> งานแบบ
      2 มิติ</td>
    <td> งานของขวัญ
      ของชำร่วย ของพรีเมี่ยม</td>
  </tr>
  <tr>
    <td  colspan="2"><strong>วัสดุที่สามารถแกะสลักด้วยเครื่องเลเซอร์</strong></td>
  </tr>
  <tr>
    <td  colspan="2">อะคริลิก,
      อลูมิเนียม ชนิด Anodize, ยาง, กระจก</td>
  </tr>
</table>

<h5 class="col_R">อุปกรณ์เพิ่มเติม</h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
  <tr>
    <td>Honeycomb </td>
    <td>ช่วยรองรับชิ้นงาน</td>
  </tr>
  <tr>
    <td>Beam Expander</td>
    <td>การตัดชิ้นงานมีความสม่ำเสมอเท่ากันทุกจุด</td>
  </tr>
  <tr>
    <td>โฟกัส เลนส์ 1.5”,2.5”</td>
    <td>1.5”  สำหรับงานที่มีจุดเล็ก<br />
      2.5” 
      สำหรับงานที่มีความหนา</td>
  </tr>
  <tr>
    <td>แบบหัวคู่</td>
    <td>เพิ่มผลผลิตได้ 2 เท่า</td>
  </tr>
</table>


<? } if($_GET["p"]=="lee") { ?>
<h2>Laser Engraver Machine : LEE</h2>
<img src="../images/product/laserlife_lee.jpg" class="boder_img" />

<h5 class="col_R">คุณสมบัติเฉพาะ</h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
  <tr align="center">
    <td colspan="4"><strong>EZ-LASER
      LEE Series</strong></td>
  </tr>
  <tr>
    <td>เลเซอร์</td>
    <td>RF
      25 Watt Sealed <br />
      CO2 Laser Tube<br />
      (Air Cooled)</td>
    <td>RF
      60 Watt Sealed CO2 Laser Tube <br />
      (Air-cooled)</td>
    <td>RF
      100 Watt Sealed<br />
      CO2 Laser Tube <br />
      (Water-cooled)</td>
  </tr>
  <tr>
    <td>น้ำหนัก</td>
    <td>200 กก </td>
    <td>210 กก </td>
    <td>230 กก </td>
  </tr>
  <tr>
    <td>พื้นที่ทำงาน (กว้างxยาว)</td>
    <td  colspan="3">914.4
      x 609.6 มม (36&quot; x 24&quot;)</td>
  </tr>
  <tr>
    <td>ขนาด (กว้างxยาวxสูง)</td>
    <td  colspan="3">955
      x 675 x 230 มม (37.6&quot;x 26.6&quot; x 9&quot;)</td>
  </tr>
  <tr>
    <td>ขนาดทั้งหมด (กว้างxยาวxสูง)</td>
    <td  colspan="3">กว้าง
      1,210 x ยาว 1,036 x สูง 1,040 มม (82.7&quot;x 84.6&quot; x
      48.2&quot;)</td>
  </tr>
  <tr>
    <td>สายคอมพิวเตอร์</td>
    <td  colspan="3">สายแบบ
      Pararel</td>
  </tr>
  <tr>
    <td>หน่วยความจำ</td>
    <td  colspan="3">64
      MB</td>
  </tr>
  <tr>
    <td>โฟกัสเลนส์</td>
    <td  colspan="3"> 2.0&quot;</td>
  </tr>
  <tr>
    <td>ความเร็วในการแกะสลัก</td>
    <td  colspan="3">1524
      มม/วินาที (60 นิ้ว/วินาที)</td>
  </tr>
  <tr>
    <td>ระบบควบคุมเลเซอร์</td>
    <td  colspan="3">ควบคุมเลเซอร์ให้ตัดชิ้น/ไม่ตัดชิ้นงานโดยใช้การควบคุมด้วยสี</td>
  </tr>
  <tr>
    <td>พลังงาน</td>
    <td  colspan="3">220VAC,
      6 Amp, 50/60Hz</td>
  </tr>
  <tr>
    <td>ซอฟต์แวร์</td>
    <td  colspan="3">EZ-LASER</td>
  </tr>
</table>

<h5 class="col_R">คุณสมบัติเด่น</h5>
<strong>คุณสมบัติเด่นของรุ่น EZ-LASER LEE</strong>
<ul type="circle">
<li>มีอุปกรณ์ช่วยทำให้ตัวเลเซอร์เคลื่อนที่ และตัดชิ้นงานได้เรียบสม่ำเสมอ
</li><li>มีการควบคุมเลเซอร์ให้ตัดชิ้น/ไม่ตัดชิ้นงานโดยใช้การควบคุมด้วยสี
</li><li>ซอฟต์แวร์ EZ-LASER ทำงานบนระบบ Windows ในการใช้งานบน CorelDraw
</li><li>สามารถตัดชิ้นงานแกะเส้นกรอบด้านนอก และการแกะสลักชิ้นงานด้านในภายในเวลาเดียวกัน
  หรือแยกทำชิ้นงานได้
</li><li>มีการออกแบบให้ง่ายต่อการเปลี่ยนชิ้นส่วนประกอบเครื่อง ง่ายต่อการบำรุงรักษา และเคลื่อนย้าย
  เครื่องได้สะดวก
</li><li>สามารถเปลี่ยนระบบการทำงานได้โดยไม่ต้องส่งไฟล์งานจากคอมพิวเตอร์ เพื่อประหยัดเวลาใน
  การทำงาน
</li><li>มีอุปกรณ์ช่วยทำให้ตัวเลเซอร์เคลื่อนที่ และตัดชิ้นงานได้เรียบสม่ำเสมอ 
</li></ul>

<table width="70%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr align="center">
    <td><img src="../images/product/laserlife_lee-1.jpg" class="boder_img" /><br />ปรับโฟกัสได้</td>
	<td width="50">&nbsp;</td>
	<td><img src="../images/product/laserlife_lee-2.jpg" class="boder_img" /><br />เลนส์โฟกัส </td>
  </tr>
</table>

<h5 class="col_R">ความต้องการพื้นฐาน</h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
    <tr>
      <td>คอมพิวเตอร์</td>
      <td>Windows 98, ME, XP</td>
    </tr>
    <tr>
      <td>ระบบระบายควัน       </td>
      <td>เครื่องระบายกลิ่นและควัน 1 ตัว (3/4HP), ความกดอากาศที่
        70 mmAq,  ลมหมุน 16m3/นาที, สายฉีด 1 เส้น ขนาดผ่าศูนย์กลาง
        6”</td>
    </tr>
</table>

<h5 class="col_R">ชิ้นงานที่ได้จากเครื่อง LEE</h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
  <tr>
    <td colspan="2"><strong>ชิ้นงานที่ได้จากเครื่อง
      LEE</strong></td>
  </tr>
  <tr>
    <td> งานอะคริลิก</td>
    <td> งานปะเก็น</td>
  </tr>
  <tr>
    <td> งานตกแต่ง<br />
    </td>
    <td> ป้ายชื่อ</td>
  </tr>
  <tr>
    <td> สัญลักษณ์<br /></td>
    <td> งานฉลุผ้า</td>
  </tr>
  <tr>
    <td> วงแหวนลูกสูบ</td>
    <td> งานฉลุลาย</td>
  </tr>
  <tr>
    <td> งานที่มีพื้นผิวหยาบ</td>
    <td> งานผ้าพลาสติกใยสังเคราะห์</td>
  </tr>
  <tr>
    <td> งานโมเดลจำลอง</td>
    <td> ตรายาง</td>
  </tr>
  <tr>
    <td> งานโมเดลของเล่น</td>
    <td> กรอบรูป</td>
  </tr>
  <tr>
    <td> งานแบบ
      2 มิติ</td>
    <td> งานของขวัญ
      ของชำร่วย ของพรีเมี่ยม</td>
  </tr>
  <tr>
    <td  colspan="2"><strong>วัสดุที่สามารถแกะสลักด้วยเครื่องเลเซอร์</strong></td>
  </tr>
  <tr>
    <td  colspan="2">อะคริลิก,
      อลูมิเนียม ชนิด Anodize, ยาง, กระจก</td>
  </tr>
</table>

<h5 class="col_R">อุปกรณ์เพิ่มเติม</h5>
<table width="100%" border="0" cellspacing="1" cellpadding="4" class="table">
  <tr>
    <td>Honeycomb </td>
    <td>ช่วยรองรับชิ้นงาน</td>
  </tr>
  <tr>
    <td>Beam Expander</td>
    <td>การตัดชิ้นงานมีความสม่ำเสมอเท่ากันทุกจุด</td>
  </tr>
  <tr>
    <td>โฟกัส เลนส์ 1.5”,2.5”</td>
    <td>1.5”  สำหรับงานที่มีจุดเล็ก<br />
      2.5” 
      สำหรับงานที่มีความหนา</td>
  </tr>
  <tr>
    <td>แบบหัวคู่</td>
    <td>เพิ่มผลผลิตได้ 2 เท่า</td>
  </tr>
</table>






<? } ?>


</td>
    </tr>
</table>




	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
