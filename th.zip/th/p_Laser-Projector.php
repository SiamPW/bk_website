<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน เครื่องฉายเลเซอร์ ไม้,โลหะ,ยางรถยนต์,ไม้กอล์ฟ,ผ้า,งานเชื่อมโลหะ,เมนบอร์ด</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
<script src="../js/change_img.js" type="text/javascript"></script>
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="29%" valign="top"><?include("../include/list_product_th.php")?></td>
    <td valign="top" style="padding:0px 0px 0px 12px;">
	<div class="head2">รายละเอียดของสินค้า<h3>Laser Projector  แบบหัวตรง : <a href="?p=kml_8000">KML-8000</a> | <a href="?p=kml_5000">KML-5000</a> | <a href="?p=kml_3000">KML-3000</a> | <a href="?p=kml_2000">KML-2000</a></h3>
	
<h3>Laser Projector  แบบหัวทแยง :  <a href="?p=kml_9000c">KML-9000</a> | <a href="?p=kml_3000c">KML-3000C</a> | <a href="?p=kml_2000c">KML-2000</a> | <a href="?p=kml_1000c">KML-1000</a></h3>

<h3>Laser Projector  แบบจุด :  <a href="?p=kml_3000p">KML-3000</a> |  <a href="?p=kml_2000p">KML-2000</a> | <a href="?p=kml_1000p">KML-1000</a> | <a href="?p=accessory">อุปกรณ์เพิ่มเติม</a></h3>
	</div>

<? if($_GET["p"]=="kml_8000" || $_GET["p"]=="") { ?>
<h2>Linear Marking-KML-8000 series (แบบหัวตรง)</h2>
<p align="center"><img alt="Laser Projector : KML-8000 series (แบบหัวตรง)" src="../images/product/kml_8000.jpg" /></p>

<h5 class="col_R"> คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-8305TC</td>
    <td>KML-8310TC</td>
    <td>KML-8320TC</td>
    <td>KML-8330TC</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>5mW</td>
    <td>10mW</td>
    <td>20mW</td>
    <td>30mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>3M</td>
    <td>6M</td>
    <td>10M</td>
    <td>15M</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>&lt; 3M</td>
    <td>&lt; 6M</td>
    <td>&lt; 10M</td>
    <td>&lt;15M</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;1.5mm</td>
    <td>&lt;2.0mm</td>
    <td>&lt;4.0mm</td>
    <td>&lt;6.0mm</td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td colspan="4">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td colspan="4">635~670nm                                (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td colspan="4">AC~260V                                50/60Hz</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>&gt;25,000                                ชม</td>
    <td>&gt;25,000                                ชม</td>
    <td>&gt;15,000                                ชม</td>
    <td>&gt;15,000                                ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td colspan="4">ยาว                                180 x กว้าง 50 x สูง 60 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td colspan="4">750                                กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td colspan="4">หิน,ไม้,โลหะ,ผ้า,งานอุตสาหกรรม                                และอื่นๆ</td>
  </tr></table>
<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/9.gif" class="img2" /><img src="../images/product/10.gif" class="boder_img" />

<? } if($_GET["p"]=="kml_5000") { ?>
<h2>Linear Marking-KML-5000 series (แบบหัวตรง)</h2>
<p align="center"><img alt="Laser Projector : KML-5000 series (แบบหัวตรง)" src="../images/product/kml_5000.jpg" width="330" /><img alt="Laser Projector : KML-5000 series (แบบหัวตรง)" src="../images/product/kml_5000_2.jpg" width="330" /></p>

<h5 class="col_R">คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-5403</td>
    <td>KML-5405</td>
    <td>KML-5305</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>3mW</td>
    <td>5mW</td>
    <td>5mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>1M</td>
    <td>2M</td>
    <td>3M</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>&lt; 1M</td>
    <td>&lt; 2M</td>
    <td>&lt; 3M</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;0.5mm (ปรับโฟกัสไม่ได้)</td>
    <td>&lt;1.0mm (ปรับโฟกัสไม่ได้)</td>
    <td>&lt;1.5mm (ปรับโฟกัสไม่ได้)</td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td colspan="3">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td colspan="3">635~670nm                                (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td colspan="3">Adaptor                                (PS1) หรือ PS3 หรือ PS5</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>&gt;20,000                                ชม</td>
    <td>&gt;20,000                                ชม</td>
    <td>&gt;15,000                                ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td colspan="3">เส้นผ่าศูนย์กลาง                                25 x ยาว 100 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td colspan="3">85                                กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td colspan="3">ไม้,โลหะ,ยางรถยนต์,ไม้กอล์ฟ,ผ้า,งานเชื่อมโลหะ,เมนบอร์ด</td>
  </tr>
</table>

<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/10.gif" class="img2" /><img src="../images/product/2.gif" class="img2" /><img src="../images/product/6.gif" class="boder_img" />



<? } if($_GET["p"]=="kml_3000") { ?>
<h2>Linear Marking-KML-3000 series (แบบหัวตรง)</h2>
<img alt="Laser Projector : KML-3000 series (แบบหัวตรง)" src="../images/product/kml_3000.jpg" width="330" /><img alt="Laser Projector : KML-3000 series (แบบหัวตรง)" src="../images/product/kml_3000_2.jpg" width="330" />
<h5 class="col_R">คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-3503</td>
    <td>KML-3505</td>
    <td>KML-3510</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>3mW</td>
    <td>5mW</td>
    <td>10mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>1M</td>
    <td>2M</td>
    <td>3M</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>&lt; 1M</td>
    <td>&lt; 2M</td>
    <td>&lt; 3M</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;0.5mm (ปรับโฟกัสไม่ได้)</td>
    <td>&lt;1.0mm (ปรับโฟกัสไม่ได้)</td>
    <td>&lt;1.5mm (ปรับโฟกัสไม่ได้)</td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td colspan="3">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td colspan="3">635~670nm                                (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td colspan="3">AC90~260V                                – DC5V Adaptor (PS1) หรือ PS3 หรือ PS5</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>&gt;15,000 ชม</td>
    <td>&gt;15,000 ชม</td>
    <td>&gt;10,000 ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td colspan="3">เส้นผ่าศูนย์กลาง                                20 x ยาว 80 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td colspan="3">50                                กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td colspan="3">ไม้,โลหะ,ยางรถยนต์,ไม้กอล์ฟ,ผ้า,งานเชื่อมโลหะ,เมนบอร์ด</td>
  </tr>
</table>

<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/10.gif" class="img2" /><img src="../images/product/2.gif" class="img2" /><img src="../images/product/6.gif" class="boder_img" />

<? } if($_GET["p"]=="kml_2000") { ?>
<h2>Linear Marking-KML-2000 series (แบบหัวตรง)</h2>
<p align="center"><img alt="Laser Projector : KML-2000 series (แบบหัวตรง)" src="../images/product/kml_2000.jpg" /></p>

<h5 class="col_R">คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-2503</td>
    <td>KML-2505</td>
    <td>KML-2508</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>3mW</td>
    <td>5mW</td>
    <td>8mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>1M</td>
    <td>2M</td>
    <td>3M</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>&lt; 1M</td>
    <td>&lt; 2M</td>
    <td>&lt; 3M</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;1.0mm (ปรับโฟกัสไม่ได้)</td>
    <td>&lt;1.5mm (ปรับโฟกัสไม่ได้)</td>
    <td>&lt;2.0mm (ปรับโฟกัสไม่ได้)</td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td colspan="3">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td colspan="3">635~670nm                                (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td colspan="3">DC                                4.5~6V (AC 90~260V – DC 5V)</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>10,000 ชม </td>
    <td>10,000 ชม </td>
    <td>10,000 ชม </td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td colspan="3">เส้นผ่าศูนย์กลาง                                15 x ยาว 60 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td colspan="3">20                                กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td colspan="3">ไม้,โลหะ,ยางรถยนต์,ไม้กอล์ฟ,ผ้า,งานเชื่อมโลหะ,เมนบอร์ด</td>
  </tr>
</table>

<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/10.gif" class="img2" /><img src="../images/product/6.gif" class="boder_img" />


<? } if($_GET["p"]=="kml_9000c") { ?>
<h2>Cross-Line Marking-KML-9000 series (แบบหัวทแยง)</h2>
<p align="center"><img alt="Cross-Line Marking-KML-9000 series (แบบหัวทแยง)" src="../images/product/kml_9000c.jpg" /></p>

<h5 class="col_R">คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-9301C</td>
    <td>KML-9303C</td>
    <td>KML-9305C</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>1mW</td>
    <td>3mW</td>
    <td>5mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>1M/เส้น</td>
    <td>2M/เส้น</td>
    <td>3M/เส้น</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>&lt; 1M</td>
    <td>&lt; 2M</td>
    <td>&lt; 3M</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;0.5mm </td>
    <td>&lt;1.0mm </td>
    <td>&lt;1.5mm </td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td colspan="3">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td colspan="3">635-670nm (แสงแดง) </td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td colspan="3">AC90~260V – DC5V Adaptor (PS1) หรือ PS3 หรือ                                PS5</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>20,000 ชม</td>
    <td>15,000 ชม</td>
    <td>10,000 ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td colspan="3">เส้นผ่าศูนย์กลาง 35 x ยาว 90 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td colspan="3">120 กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td colspan="3">งานผ้า</td>
  </tr>
</table>

<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/14.gif" class="boder_img" />


<? } if($_GET["p"]=="kml_3000c") { ?>
<h2>Cross-Line Marking-KML-3000C series (แบบหัวทแยง)</h2>
<img alt="Cross-Line Marking-KML-3000C series (แบบหัวทแยง)" src="../images/product/kml_3000c.jpg" width="330" /><img src="../images/product/kml_3000_2.jpg" width="330" />

<h5 class="col_R"> คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-3501C</td>
    <td>KML-3502C</td>
    <td>KML-3503C</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>1mW</td>
    <td>2mW</td>
    <td>3mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>15ซม/เส้น</td>
    <td>30ซม/เส้น</td>
    <td>45ซม/เส้น</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>&lt; 1M</td>
    <td>&lt; 2M</td>
    <td>&lt; 3M</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;0.5mm </td>
    <td>&lt;1.0mm </td>
    <td>&lt;2.0mm </td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td colspan="3">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td colspan="3">635~670nm (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td colspan="3">AC90~260 – DC5V Adaptor (PS1) หรือ PS3 หรือ                                PS5</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>&gt;20,000                                ชม</td>
    <td>&gt;15,000                                ชม</td>
    <td>&gt;10,000                                ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td colspan="3">เส้นผ่าศูนย์กลาง 20 x ยาว 72 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td colspan="3">50 กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td colspan="3">ไม้,โลหะ,ยางรถยนต์,ไม้กอล์ฟ,ผ้า,งานเชื่อมโลหะ,เมนบอร์ด</td>
  </tr>
</table>

<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/14.gif" class="img2" /><img src="../images/product/1.gif" class="img2" /><img src="../images/product/8.gif" class="boder_img" /><br /><img src="../images/product/6.gif" class="img2" />


<? } if($_GET["p"]=="kml_2000c") { ?>
<h2>Cross-Line Marking-KML-2000 series (แบบหัวทแยง)</h2>
<p align="center"><img alt="Cross-Line Marking-KML-2000 series (แบบหัวทแยง)" src="../images/product/kml_2000c.jpg" /></p>
<h5 class="col_R">คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-2501C</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>1mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>1.5/3/4.5/6/7.5                                ซม/1เส้น</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>10/20/30/40/50                                ซม</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;0.5mm </td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td>เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td>635~670nm                                (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>AC90~260V                                – DC5V Adaptor (PS1) หรือ PS3หรือ PS5</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>&gt;10,000                                ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td>เส้นผ่าศูนย์กลาง                                15 x ยาว 53 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td>16 กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td>เลื่อยชิ้นงาน                                และทำฉาก</td>
  </tr>
</table>

<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/1.gif" class="img2" /><img src="../images/product/8.gif" class="boder_img" />




<? } if($_GET["p"]=="kml_1000c") { ?>
<h2>Cross-Line Marking-KML-1000 series (แบบหัวทแยง)</h2>
<p align="center"><img alt="Cross-Line Marking-KML-1000 series (แบบหัวทแยง)" src="../images/product/kml_1000c.jpg" /></p>
<h5 class="col_R"> คุณสมบัติเด่น : </h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td align="left">รุ่น</td>
    <td>KML-1501C-50</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>1mW</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะจุด</td>
    <td>1.5/3/4.5/6/7.5                                ซม/1เส้น</td>
  </tr>
  <tr align="center">
    <td align="left">ระยะการมองเห็น</td>
    <td>10/20/30/40/50                                ซม</td>
  </tr>
  <tr align="center">
    <td align="left">ความกว้างของเส้น</td>
    <td>&lt;0.5mm </td>
  </tr>
  <tr align="center">
    <td align="left">เลเซอร์</td>
    <td>เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td align="left">ความยาวคลื่น</td>
    <td>635~670nm                                (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td align="left">พลังงาน</td>
    <td>AC90~260V                                – DC5V Adaptor (PS1) หรือ PS3หรือ PS5</td>
  </tr>
  <tr align="center">
    <td align="left">อายุการใช้งาน</td>
    <td>&gt;10,000                                ชม</td>
  </tr>
  <tr align="center">
    <td align="left">ขนาดตัวเครื่อง</td>
    <td>เส้นผ่าศูนย์กลาง                                12 x ยาว 53 (มม)</td>
  </tr>
  <tr align="center">
    <td align="left">น้ำหนัก</td>
    <td>13 กรัม</td>
  </tr>
  <tr align="center">
    <td align="left">การประยุกต์ใช้งาน</td>
    <td>เลื่อยชิ้นงาน                                และทำฉาก</td>
  </tr>
</table>


<h5 class="col_R">การประยุกต์ใช้งาน</h5>
<img src="../images/product/1.gif" class="img2" /><img src="../images/product/8.gif" class="boder_img" />


<? } if($_GET["p"]=="kml_3000p") { ?>
<h2>Point Marking-KML-3000 series (แบบจุด)</h2>
<p align="center"><img alt="Point Marking-KML-3000 series (แบบจุด)" src="../images/product/kml_3000p.jpg" /></p>
<h5 class="col_R">คุณสมบัติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td>รุ่น</td>
    <td>KML-3501P</td>
    <td>KML-3502P</td>
  </tr>
  <tr align="center">
    <td>กำลังไฟ</td>
    <td>1mW</td>
    <td>2mW</td>
  </tr>
  <tr align="center">
    <td>ระยะการมองเห็น</td>
    <td colspan="2">&lt;3M</td>
  </tr>
  <tr align="center">
    <td>เส้นผ่าศูนย์กลาง</td>
    <td colspan="2">&lt;2.0mm (ปรับโฟกัสได้)</td>
  </tr>
  <tr align="center">
    <td>เลเซอร์</td>
    <td colspan="2">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td>ความยาวคลื่น</td>
    <td colspan="2">635~670nm (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td>พลังงาน(power                                supply)</td>
    <td colspan="2">AC90~260V – DC5V Adaptor หรือ PS3 หรือ PS5</td>
  </tr>
  <tr align="center">
    <td>อายุการใช้งาน</td>
    <td colspan="2">&gt;15,000 ชม</td>
  </tr>
  <tr align="center">
    <td>ขนาดตัวเครื่องน้ำหนัก</td>
    <td colspan="2">เส้นผ่าศูนย์กลาง 20 x ยาว 72 (มม)</td>
  </tr>
  <tr align="center">
    <td>Weight</td>
    <td colspan="2">50                                กรัม</td>
  </tr>
  <tr align="center">
    <td>การประยุกต์ใช้งาน</td>
    <td colspan="2">ใช้ชี้ตำแหน่งข้อมูล</td>
  </tr>
</table>


<? } if($_GET["p"]=="kml_2000p") { ?>
<h2>Point Marking-KML-2000 series (แบบจุด)</h2>
<p align="center"><img alt="Point Marking-KML-2000 series (แบบจุด)" src="../images/product/kml_2000p.jpg" /></p>
<h5 class="col_R">คุณสมบัุติเด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td>รุ่น</td>
    <td>KML-2501P</td>
  </tr>
  <tr align="center">
    <td>กำลังไฟ</td>
    <td>1mW</td>
  </tr>
  <tr align="center">
    <td>ระยะการมองเห็น</td>
    <td>&lt;3M</td>
  </tr>
  <tr align="center">
    <td>เส้นผ่าศูนย์กลาง</td>
    <td>&lt;2.0mm</td>
  </tr>
  <tr align="center">
    <td>เลเซอร์</td>
    <td>เลเซอร์ไดโอด</td>
  </tr>
  <tr align="center">
    <td>ความยาวคลื่น</td>
    <td>635~670nm (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td>พลังงาน(power                                supply)</td>
    <td>AC90~260V –                                DC5V Adaptor (PS1) หรือ PS3 หรือ PS5</td>
  </tr>
  <tr align="center">
    <td>อายุการใช้งาน</td>
    <td>15,000 ชม</td>
  </tr>
  <tr align="center">
    <td>ขนาดตัวเครื่องน้ำหนัก</td>
    <td>เส้นผ่าศูนย์กลาง                                15 x ยาว 50 (มม)</td>
  </tr>
  <tr align="center">
    <td>Weight</td>
    <td>15 กรัม</td>
  </tr>
  <tr align="center">
    <td>การประยุกต์ใช้งาน</td>
    <td>ใช้ชี้ตำแหน่งข้อมูล</td>
  </tr>
</table>


<? } if($_GET["p"]=="kml_1000p") { ?>
<h2>Point Marking-KML-1000 series (แบบจุด)</h2>
<p align="center"><img alt="Point Marking-KML-1000 series" src="../images/product/kml_1000p.jpg" /></p>
<h5 class="col_R">คุณสมบัติเ่ด่น :</h5>
<table width="100%" cellspacing="1" cellpadding="4" class="table">
  <tr align="center" style="font-weight:bold;">
    <td>รุ่น</td>
    <td>KML-1501P-50</td>
    <td>KML-1501P</td>
  </tr>
  <tr align="center">
    <td>กำลังไฟ</td>
    <td colspan="2">&lt;1mW</td>
  </tr>
  <tr align="center">
    <td>ระยะการมองเห็น</td>
    <td>&lt;3mW</td>
    <td>&lt;3mW</td>
  </tr>
  <tr align="center">
    <td>เส้นผ่าศูนย์กลาง</td>
    <td colspan="2">&lt;2.0mm</td>
  </tr>
  <tr align="center">
    <td>เลเซอร์</td>
    <td colspan="2">เลเซอร์ชนิดแบบไดโอด</td>
  </tr>
  <tr align="center">
    <td>ความยาวคลื่น</td>
    <td colspan="2">635~670nm (แสงแดง)</td>
  </tr>
  <tr align="center">
    <td>พลังงาน(power                                supply)</td>
    <td>AC90~260V                                – DC5V Adaptor<br />
      หรือ PS3 หรือ PS5</td>
    <td>DC~6V (ใช้แบตเตอรี่)</td>
  </tr>
  <tr align="center">
    <td>อายุการใช้งาน</td>
    <td>15,000 ชม</td>
    <td>&gt;8,000                                ชม</td>
  </tr>
  <tr align="center">
    <td>ขนาดตัวเครื่องน้ำหนัก</td>
    <td>เส้นผ่าศูนย์กลาง                                12 x ยาว 50 (มม)</td>
    <td>เส้นผ่าศูนย์กลาง                                12 x ยาว 35 (มม)</td>
  </tr>
  <tr align="center">
    <td>Weight</td>
    <td>12 กรัม</td>
    <td>10 กรัม</td>
  </tr>
  <tr align="center">
    <td>การประยุกต์ใช้งาน</td>
    <td colspan="2">ใช้ชี้ตำแหน่งข้อมูล</td>
  </tr>
</table>


<? } if($_GET["p"]=="accessory") { ?>
<h2>อุปกรณ์เพิ่มเติม </h2>
<table width="100%" border="0" cellspacing="15" cellpadding="0">
  <tr align="center">
    <td><img src="../images/product/accessory01.jpg" /></td><td><img src="../images/product/accessory02.jpg" /></td>
  </tr>
  <tr align="center">
    <td><img src="../images/product/accessory03.jpg" /></td><td><img src="../images/product/accessory04.jpg" /></td>
  </tr>
</table>


<? } ?>



</td>
    </tr>
</table>




	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
