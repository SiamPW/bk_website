<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="laser pw, pw laser, pw, เลเซอร์สำหรับงานตัด, สำหรับงานอโลหะ, เลเซอร์สำหรับงานแกะสลัก, สำหรับงานอโลหะ, เลเซอร์สำหรับงาน Marking, สำหรับงานอโลหะ, บริการตัดงานอโลหะ, บริการตัดแกะสลักงานอโลหะ, บริการงาน Marking อโลหะ, เลเซอร์สำหรับเครื่องฉายภาพสไลด์, อุปกรณ์เครื่องมือเกี่ยวกับงานทางด้านอะคลิริก" />
<meta name="description" content="เราเป็นหนึ่งในตัวแทนจำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน บริษัทมีความเชี่ยวชาญ และมีประสปการณ์ในการดูแลรักษา และซ่อม บำรุงเครื่องเลเซอร์มากว่า 5 ปี"/>
<meta name="robots" content="all,follow" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PW laser : จำหน่ายและให้บริการ เครื่องเลเซอร์จากประเทศไต้หวัน เครื่องตัดเลเซอร์</title>
<link href="../css.css" rel="stylesheet" type="text/css" />
<script src="../js/change_img.js" type="text/javascript"></script>
</head>

<body>
<table width="950" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding:10px 0px;">
	<?include("../include/top.php")?>	</td>
  </tr>
  <tr>
    <td bgcolor="#000000" style="padding-left:30px;">
	<?include("../include/mainmenu_th.php")?>	</td>
  </tr>
  <tr>
    <td style="padding:5px 0px;"><?include("../include/img_slide.php")?></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="29%" valign="top"><?include("../include/list_product_th.php")?></td>
    <td valign="top" style="padding:0px 0px 0px 12px;">
	<div class="head2">รายละเอียดของสินค้า<h3>Laser Cutting Machine :  | <a href="?p=c2">C2</a> | <a href="?p=e2">E2</a> | <a href="?p=k2">K2</a> | <a href="?p=s2">S2</a> | <a href="?p=s1">S1</a></h3>
	</div>

<!--Laser Cutting Machine-->
<? if($_GET["p"]=="c2" || $_GET["p"]=="") { ?>
<h2>Laser Cutting Machine : C2 เครื่องเลเซอร์สำหรับงานตัด</h2>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
  <tbody>
    <tr>
      <td><img src="../images/product/c2.jpg" /></td>
      <td><h5>คุณลักษณะของเครื่องเลเซอร์โดยทั่วไป </h5>
          <ul type="circle">
            <li>เครื่องเลเซอร์ชนิด CO2 มีทั้งแบบ 50 W และ 100 W</li>
            <li>ระบบทำงานแบบสายพาน </li>
            <li>พื้นที่ในการตัดชิ้นงานขนาด 390 มม x 550 มม </li>
            <li>ความเร็วในการตัด 20 ซม/วินาที </li>
            <li>กล้อง CCD ไว้จับตำแหน่งในการตัดชิ้นงาน </li>
            <li>คอมพิวเตอร์ ใช้ PENTIUM , จอมอนิเตอร์สี , สแกนเนอร์ </li>
            <li>ขนาด 170 x 88 x 125 ซม </li>
            <li>น้ำหนัก 300 กก </li>
            <li>ใช้ไฟ 220 V/50-60 HZ , 10 A </li>
          </ul></td>
    </tr>
  </tbody>
</table>
<h5>คุณสมบัติพิเศษ </h5>
<ol type="1" start="1">
  <li>มีระบบสายพานในการป้อนชิ้นงานเข้าเครื่องที่เร็ว และแน่นอน</li>
  <li>มีกล้อง CCD ไว้คอยจับตำแหน่งของชิ้นงาน </li>
  <li>ตัวเลเซอร์มีคุณภาพสูง และสามารถใช้งานได้ต่อเนื่อง   เพราะมีเครื่องหล่อเย็นไว้ช่วยระบายความร้อน </li>
  <li>ระบบคอมพิวเตอร์ทำงานได้ทั้งภาษาอังกฤษ และจีน,สามารถปรับแต่งชิ้นงาน   และขนาดได้อย่างแน่นอน โดยการสั่งงานผ่านคอมพิวเตอร์ ,   ควบคุมอัตราความเร็วในการตัดได้โดยคอมพิวเตอร์,   กำหนดความเร็วในการตัดชิ้นงานที่มีความหนาที่แตกต่างกันในชิ้นงานตัวเดียวกัน </li>
  <li>เครื่องเลเซอร์ถูกออกแบบมาให้ทนทาน และทำงานได้อย่างมีประสิทธิภาพ </li>
  <li>การตัดชิ้นงานมีคุณภาพสูง </li>
  <li>ระบบสายพานลำเลียงชิ้นงานมีคุณภาพสูง </li>
  <li>สามารถปรับแต่งการตัดชิ้นงานให้เหมาะสมกับการตัดแต่ละชนิดได้ </li>
</ol>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
  <tbody>
    <tr valign="top" align="middle">
      <td><img src="../images/product/e2_01.jpg" /><br />
        มีกล้อง CCD   ไว้คอยจับตำแหน่ง ของชิ้นงาน, ปรับและข้ามชิ้นงานได้ โดยอัตโนมัติ</td>
      <td><img src="../images/product/c2_01.jpg" /><br />
        มีรีโมทคอนโทรลสั่งงานแทน คีย์บอร์ด</td>
      <td><img src="../images/product/c2_02.jpg" /><br />
        มีระบบสายพานในการ   ป้อนชิ้นงานเข้าเครื่องที่เร็ว และแน่นอน</td>
    </tr>
    <tr>
      <td colspan="3"> </td>
    </tr>
    <tr valign="top" align="middle">
      <td><img src="../images/product/c2_04.jpg" /><br />
        ตัวเลเซอร์มีความทนทานเพราะ   มีเครื่องหล่อเย็นไว้คอยระบาย ความร้อน</td>
      <td><img src="../images/product/c2_05.jpg" /><br />
        ระบบคอมพิวเตอร์ทำงานได้ ทั้งภาษาอังกฤษ   และจีน ,สามารถกำหนดอัตราความเร็ว , ปรับแต่งชิ้นงาน และขนาดได้ </td>
    </tr>
  </tbody>
</table>
<p>
  <? } if($_GET["p"]=="e2") { ?>
</p>
<h2>Laser Cutting Machine : E2 เครื่องเลเซอร์สำหรับงานตัด</h2>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="../images/product/e2.jpg" /></td><td style="padding-left:20px;"><img class="boder_img" src="../images/product/e2_01.jpg" /><br />มีกล้อง CCD ไว้คอยจับตำแหน่ง ของชิ้นงาน, ปรับและข้ามชิ้นงาน ได้โดยอัตโนมัติ</td>
  </tr>
</table>

<h5 class="col_R">คุณลักษณะของเครื่องเลเซอร์โดยทั่วไป</h5>
<table border="0" cellspacing="1" cellpadding="4" width="100%" class="table">
  <tr style="font-weight:bold;">
    <td>รุ่น</td>
    <td>E2</td>
  </tr>
  <tr>
    <td>เลเซอร์ CO2</td>
    <td>25 วัตต์</td>
  </tr>
  <tr>
    <td>ระบบขับเคลื่อน</td>
    <td>ระบบทิศทางเดียว</td>
  </tr>
  <tr>
    <td>พื้นที่การทำงาน</td>
    <td>600 มม x 800 มม</td>
  </tr>
  <tr>
    <td>อัตราความเร็วในการตัดสูงสุด</td>
    <td>12 ซม/วินาที</td>
  </tr>
  <tr>
    <td>อุปกรณ์ช่วยจับภาพ</td>
    <td>กล้อง CCD</td>
  </tr>
  <tr>
    <td>ขนาด</td>
    <td>กล่องที่ใส่ตัวเครื่อง ยาว 200 x กว้าง 120 x สูง 150 ซม<br />
      ตัวเครื่อง ยาว 152   x กว้าง 88* x สูง 170# ซม<br />
      *กว้าง 126 ซม   รวมแกนหมุนที่คอยพยุงผ้าที่ด้านหลัง<br />
      # สูง 167 ซม   เมื่อเปิดฝาเครื่อง</td>
  </tr>
  <tr>
    <td>น้ำหนัก</td>
    <td>โดยประมาณ 220 กก (Net) , โดยประมาณ 270 กก   (Gross)</td>
  </tr>
  <tr>
    <td>พลังงาน</td>
    <td>220 V/50-60 Hz, 10 A Max</td>
  </tr></table>
  
<h5 class="col_R">คุณสมบัติพิเศษ</h5>
<table border="0" cellspacing="1" cellpadding="4" width="100%" class="table">
  <tr style="font-weight:bold;">
    <td>รุ่น</td>
    <td>E2</td>
  </tr>
  <tr>
    <td>เลเซอร์ CO2</td>
    <td>25 วัตต์</td>
  </tr>
  <tr>
    <td>ระบบทำความเย็น</td>
    <td>เครื่องหล่อเย็น</td>
  </tr>
  <tr>
    <td>ระบบควบคุมคอมพิวเตอร์</td>
    <td>มี</td>
  </tr>
  <tr>
    <td>ระบบควบคุมการตัด</td>
    <td>สามารถปรับแต่งการตัดได้</td>
  </tr>
  <tr>
    <td>ระบบควบคุมความเร็วในการตัด</td>
    <td>สามารถปรับความเร็วได้</td>
  </tr>
  <tr>
    <td>อุปกรณ์ช่วยในการจับภาพ</td>
    <td>มี</td>
  </tr>
  <tr>
    <td>อุปกรณ์ช่วยในการจับภาพ</td>
    <td>กล้อง CCD (option)</td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr align="center" valign="top">
    <td><img class="boder_img" src="../images/product/e2_02.jpg" /><br />มี Honey Comb ไว้รองรับผ้า ทำให้การตัดผ้าเป็นไปอย่างม
ีประสิทธิภาพ</td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/e2_03.jpg" /><br />สามารถตัดงานที่มีหลายสี ได้อย่างง่ายโดยใช้การประยุกต์ โปรแกรมใช้งานร่วมกันได้</td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/e2_04.jpg" /><br />สามารถตัดชิ้นงานได้หลายแบบ เช่น งานตัดที่มีชั้นเดียว , หลายชั้น , การฉลุลาย , ตราเครื่องหมาย และหนังได้  </td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
    <tr align="center" valign="top">
    <td><img class="boder_img" src="../images/product/e2_05.jpg" /><br />เลเซอร์แบบ CO2 ทำจากอเมริกา มีประสิทธิภาพในการใช้งาน ที่ยาวนาน</td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/e2_06.jpg" /><br />ตัวที่ตัดงานนั้นมีน้ำหนักเบา ,มีหัวฉีดลม และมีระบบระบายควัน ที่มีประสิทธิภาพ</td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/e2_07.jpg" /><br />มีระบบแกนหมุนที่คอยพยุงผ้า ที่ด้านหลัง</td>
  </tr>
</table>



<? } if($_GET["p"]=="k2") { ?>
<h2>Laser Cutting Machine : K2 เครื่องเลเซอร์สำหรับงานตัด</h2>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="../images/product/k2.jpg" /></td><td><h5 class="col_R">คุณลักษณะของเครื่องเลเซอร์โดยทั่วไป </h5>
<ul type="circle">
<li>เครื่องเลเซอร์ชนิด CO2 มีทั้งแบบ 50 W และ 100 W</li><li>ระบบขับเคลื่อนแบบ BALL SCREWS 
</li><li>พื้นที่ในการตัดชิ้นงานขนาด 180 มม x 220 มม 
</li><li>ความเร็วในการตัด 20 ซม/วินาที 
</li><li>กล้อง CCD ไว้จับตำแหน่งในการตัดชิ้นงาน 
</li><li>คอมพิวเตอร์ ใช้ PENTIUM , จอมอนิเตอร์สี , สแกนเนอร์
</li><li>ขนาด สูง 200 x กว้าง 88 x สูง 125 ซม
</li><li>น้ำหนัก 200 กก 
</li><li>ใช้ไฟ 220 V/50-60 HZ , 10 A  
</li></ul>
ิ</td>
  </tr>
</table>

<h5 class="col_R">คุณสมบัติพิเศษ </h5>
<ol type="1" start="1">
<li>ใช้เซอร์โวมอเตอร์ความเร็วสูง สำหรับงานที่ต้องการคุณภาพสูง</li><li>มีกล้อง CCD ไว้คอยจับตำแหน่งของชิ้นงาน
</li><li>ตัวเลเซอร์มีคุณภาพสูง และสามารถใช้งานได้ต่อเนื่อง เพราะมีเครื่องหล่อเย็นไว้ช่วยระบายความร้อน 
</li><li>ระบบคอมพิวเตอร์ทำงานได้ทั้งภาษาอังกฤษ และจีน,สามารถปรับแต่งชิ้นงาน และขนาดได้อย่างแน่นอน โดยการสั่งงานผ่านคอมพิวเตอร์ , ควบคุมอัตราความเร็วในการตัดได้โดยคอมพิวเตอร์ ,กำหนดความเร็วในการตัดชิ้นงานที่มีความหนาที่แตกต่างกันในชิ้นงานตัวเดียวกัน 
</li><li>เครื่องเลเซอร์ถูกออกแบบมาให้ทนทาน และทำงานได้อย่างมีประสิทธิภาพ 
</li><li>การตัดชิ้นงานมีคุณภาพสูง  
</li><li>มีตัวอัดอากาศไว้ช่วยในการตัดชิ้นงานไม่ให้ตึงเกินไป  
</li><li>สามารถปรับแต่งการตัดชิ้นงานให้เหมาะสมกับการตัดแต่ละชนิดได้ </li>
</ol>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr align="center" valign="top">
    <td><img class="boder_img" src="../images/product/e2_01.jpg" /><br />มีกล้อง CCD ไว้คอยจับตำแหน่ง ของชิ้นงาน, ปรับและข้ามชิ้นงาน ได้โดยอัตโนมัติ</td>
    <td width="20">&nbsp;</td>
    <td><img class="boder_img" src="../images/product/k2_04.jpg" /><br />ใช้เซอร์โวมอเตอร์ความเร็วสูง สำหรับงานที่ต้องการคุณภาพสูง</td>
    <td width="20">&nbsp;</td>
    <td><img class="boder_img" src="../images/product/k2_05.jpg" /><br />การตัดชิ้นงานมีความแน่นอน</td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr align="center" valign="top">
    <td><img class="boder_img" src="../images/product/k2_06.jpg" /><br />มีตัวอัดอากาศไว้ช่วย ในการตัด ชิ้นงานไม่ให้ตึงเกินไป</td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/c2_04.jpg" /><br />ตัวเลเซอร์มีคุณภาพสูงและ สามารถใช้งานได้ต่อเนื่องเพราะ มีเครื่องหล่อเย็นไว้ช่วยระบาย ความร้อน</td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/c2_05.jpg" /><br />ระบบคอมพิวเตอร์ทำงานได้ทั้ง ภาษาอังกฤษ และจีน,สามารถ กำหนดอัตรา ความเร็ว, ปรับแต่ง ชิ้นงาน และขนาดได้ </td>
  </tr>
</table>



<? } if($_GET["p"]=="s2") { ?>
<h2>Laser Cutting Machine : S2 เครื่องแกะสลักและตัด</h2>
<div style="margin-right:20px; float:left;"><img src="../images/product/s2.jpg" /></div>
<h5 class="col_R">คุณลักษณะของเครื่องเลเซอร์โดยทั่วไป </h5>
<table width="59%" border="0" cellspacing="1" cellpadding="4" class="table">
  <tr>
    <td>เลเซอร์</td>
    <td>เลเซอร์แบบ CO2 (อเมริกา) 60 วัตต์</td>
  </tr>
  <tr>
    <td>ระบบหล่อเย็น</td>
    <td>พัดลม</td>
  </tr>
  <tr>
    <td>อุปกรณ์ช่วยดูชิ้นงานก่อนตัด</td>
    <td>มีจุดสีแดงไว้ช่วยในการมอง</td>
  </tr>
  <tr>
    <td>พื้นที่การทำงาน</td>
    <td>500 มม x 500 มม<br />
      500 มม x 1300 มม   (รวมการเปิดแบบอัตโนมัติ</td>
  </tr>
  <tr>
    <td>พื้นที่ใช้สอยสำหรับชิ้นงานที่สูง</td>
    <td>740 มม</td>
  </tr>
  <tr>
    <td>การปรับระดับความสูง</td>
    <td>N/A</td>
  </tr>
  <tr>
    <td>อุปกรณ์ช่วยพยุงชิ้นงาน</td>
    <td>Honey Comb</td>
  </tr>
  <tr>
    <td>เครื่องเป่า</td>
    <td>1 /2 HP กับสายยาว 10 เมตร</td>
  </tr>
  <tr>
    <td>ฝาครอบวัสดุในขณะทำงาน</td>
    <td>กล่องอะคริลิก , ขึ้นลงอัตโนมัติ</td>
  </tr>
  <tr>
    <td>ขนาดของจุด (1/e2)</td>
    <td>0.5 มม</td>
  </tr>
  <tr>
    <td>ความเร็วในการแกะสลัก</td>
    <td>100 มม/วินาที - 2,500 มม/วินาที</td>
  </tr>
  <tr>
    <td>ขนาด</td>
    <td>กว้าง 150 x ลึก 130 x สูง 175 ซม</td>
  </tr>
  <tr>
    <td>น้ำหนัก </td>
    <td>300 กก</td>
  </tr>
  <tr>
    <td>พลังงาน</td>
    <td>1 เฟส 220V/50-60 Hz</td>
  </tr>
  <tr>
    <td>กินไฟ</td>
    <td>สูงสุด 3000 วัตต์</td>
  </tr>
</table>
<br />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr align="center" valign="top">
    <td><img class="boder_img" src="../images/product/s2_01.jpg" /><br />งานตัวอย่าง</td>
    <td width="25">&nbsp;</td>
    <td><img class="boder_img" src="../images/product/s2_02.jpg" /><br />งานตัวอย่าง</td>
    <td width="25">&nbsp;</td>
    <td><img class="boder_img" src="../images/product/s2_03.jpg" /><br />งานตัวอย่าง</td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr align="center" valign="top">
    <td><img class="boder_img" src="../images/product/e2_05.jpg" /><br />เลเซอร์แบบ CO2 ทำจากอเมริกา มีประสิทธิภาพในการใช้งานที่ ยาวนาน</td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/c2_05.jpg" /><br />ระบบคอมพิวเตอร์ทำงานได้ทั้ง ภาษาอังกฤษ และจีน, สามารถ กำหนด อัตรา ความเร็ว, ปรับแต่ง ชิ้นงานและขนาดได้ </td>
    <td>&nbsp;</td>
    <td><img class="boder_img" src="../images/product/e2_02.jpg" /><br />มี Honey Comb ไว้คอยพยุงผ้า ทำให้การตัดผ้าเป็นไปอย่างม ีประสิทธิภาพ</td>
  </tr>
</table>
<p>
  <? } if($_GET["p"]=="s1") { ?>
<h2>Laser Cutting Machine : S1 เครื่องเลเซอร์สำหรับงานตัด</h2>
<br />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><img src="../images/product/S1.jpg" width="350" class="img2"/></td>
  </tr>
  <tr>
    <td><br /><img src="../images/product/S1_2.jpg" class="img2" />
</td>
  </tr>
</table>



  <? } ?>
  <!--end Laser Cutting Machine-->
      </h2>
</p>
</td>
  </tr>
</table>




	</td>
  </tr>
  
  <tr>
    <td style="padding-top:10px;"><?include("../include/foor.php")?></td>
  </tr>
</table>
</body>
</html>
